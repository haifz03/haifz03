<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Mới Sản Phẩm</title>
    <link rel="stylesheet" href="add-style.css">
<?php
include("connect.php");

// Xử lý dữ liệu submit bằng phương thức POST của người dùng
if (isset($_POST['submit'])) {
    $fullnamesp = $_POST['product_name'];
    $image = $_FILES['product_image']['name']; // Lấy tên file hình ảnh
    $oprice = $_POST['old_price'];
    $nprice = $_POST['new_price'];
    $discout = $_POST['discount'];

    // Kiểm tra và tải lên hình ảnh
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
        $targetDir = "image/"; // Thư mục lưu ảnh
        $targetFile = $targetDir . basename($_FILES["product_image"]["name"]);
        move_uploaded_file($_FILES["product_image"]["tmp_name"], $targetFile);
        $image = $targetFile;
    } else {
        $image = "image/default.jpg"; // Đường dẫn mặc định nếu không có ảnh
    }

    // Câu lệnh INSERT
    $sql = "INSERT INTO products(namesp, imagesp, old_price, new_price, discounts) 
            VALUES('$fullnamesp', '$image', '$oprice', '$nprice', '$discout')";

    // Thực thi câu lệnh SQL
    $result = $conn->query($sql);

    // Kiểm tra lỗi
    if (!$result) {
        die("Lỗi kết nối: " . $conn->connect_error);
    }

    // Chuyển tiếp về trang index khi thêm mới thành công
    header("Location: index.php");
    exit;
}
?>
</head>
<body>
    <div class="title-container">
            <div class="title">THÊM MỚI SẢN PHẨM</div>
        </div>
    <div class="container">
        <form method="post" enctype="multipart/form-data">
            <div>
                <label for="product_name">Tên sản phẩm</label>
                <input type="text" name="product_name" required>
            </div>

            <div class="choose">
                <label class="upload-button" for="product_image">
                    <input type="file" id="product_image" name="product_image" onchange="updateFileName()">
                </label>
                <span class="file-name" id="file-name">No file chosen</span>
            </div>

            <div>
                <label for="old_price">Giá cũ</label>
                <input type="text" name="old_price" required>
            </div>

            <div>
                <label for="new_price">Giá mới</label>
                <input type="text" name="new_price" required>
            </div>

            <div>
                <label for="discount">Phần trăm giảm giá</label>
                <input type="text" name="discount" required>
            </div>

            <input type="submit" name="submit" value="Thêm mới">
            <a href="index.php"><input type="button" value="Hủy" class="cancel"></a> 
        </form>
    </div>
</body>
</html>
