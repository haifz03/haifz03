<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lí Danh Mục Sản Phẩm</title>
    <link rel="stylesheet" href="in-style.css">
</head>
<body>
    <div class="header-container">
        <div class="header">DANH MỤC SẢN PHẨM LAPTOP</div>
    </div>

    <div class="button-add-container">
        <a href="add.php" class="button-add">Thêm sản phẩm</a>
    </div>

    <div class="container">
        <?php
        include "connect.php"; // Kết nối cơ sở dữ liệu

        $sql = "SELECT * FROM products";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Hiển thị danh sách sản phẩm
            while ($row = $result->fetch_assoc()) {
                echo '<div class="card">
                        <img src="' . $row['imagesp'] . '" alt="Laptop" class="image">
                        <div class="info">
                            <h3>' . $row['namesp'] . '</h3>
                            <p class="old-price">' . $row['old_price'] . 'đ</p>
                            <span class="discount">' . $row['discounts'] . '%</span>
                            <p class="new-price">' . $row['new_price'] . 'đ</p>
                            <div class="buttons">
                                <a href="update.php?id=' . $row['id'] . '" class="edit-btn">Sửa</a>
                                <a href="delete.php?id=' . $row['id'] . '" class="delete-btn" onclick="return confirm(\'Bạn có chắc muốn xóa sản phẩm này?\');">Xóa</a>
                            </div>
                        </div>
                    </div>';
            }
        } else {
            echo '<p>Chưa có sản phẩm nào</p>';
        }
        ?>
    </div>
</body>
</html>
