<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cập nhật danh mục sản phẩm</title>
    <link rel="stylesheet" href="up-style.css">
<?php
include("connect.php");
$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // GET METHOD: Gán dữ liệu vào các thẻ input
    if (!isset($id)) {
        header("Location: index.php");
        exit;
    }

    $sql = "SELECT * FROM products WHERE id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    if (!$row) {
        header("Location: index.php");
        exit;
    }

    $fullnamesp = $row["namesp"];
    $image = $row['imagesp']; // Lấy tên hình ảnh từ cơ sở dữ liệu
    $oprice = $row['old_price'];
    $nprice = $row['new_price'];
    $discout = $row['discounts'];
} else {
    // POST METHOD: Xử lý sửa dữ liệu khi người dùng nhấn nút Cập nhật
    $fullnamesp = $_POST['product_name'];
    $image = $_FILES['product_image']['name']; // Lấy tên file hình ảnh
    $oprice = $_POST['old_price'];
    $nprice = $_POST['new_price'];
    $discout = $_POST['discount'];

    // Kiểm tra và tải lên hình ảnh
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
        $targetDir = "image/"; // Thư mục lưu ảnh
        $targetFile = $targetDir . basename($_FILES["product_image"]["name"]);
        move_uploaded_file($_FILES["product_image"]["tmp_name"], $targetFile);
        $image = $targetFile;
    } else {
        $image = $_POST['current_image']; // Giữ hình ảnh hiện tại nếu không thay đổi
    }

    $sql = "UPDATE products
            SET namesp='$fullnamesp', imagesp='$image', old_price='$oprice', new_price='$nprice', discounts='$discout' 
            WHERE id='$id'";

    $result = $conn->query($sql);

    if (!$result) {
        die("Lỗi kết nối: " . $conn->connect_error);
    }

    header("Location: index.php");
    exit;
}
?>
</head>
<body>
    <div class="title-container">
                <div class="title">CẬP NHẬT DANH MỤC SẢN PHẨM</div>
            </div>
    <div class="container">
        
        <form method="post" enctype="multipart/form-data">
            <div>
                <label>Mã sản phẩm</label>
                <input type="text" name="id" id="id" disabled value="<?php echo $id; ?>">
            </div>

            <div>
                <label for="product_name">Tên sản phẩm</label>
                <input type="text" name="product_name" value="<?php echo $fullnamesp; ?>" required>
            </div>

            <div><label>Hình sản phẩm</label></div>

            <div class="image">
                <img src="<?php echo $image; ?>" alt="Image" class="product-image">
            </div>
            <div><label>Thay hình mới:</label></div>
            <div class="choose">
                <label class="upload-button" for="product_image">
                    <input type="file" id="product-image" class="file-input" name="product_image" onchange="updateFileName()">
                </label>
                <span class="file-name" id="file-name">No file chosen</span>
            </div>

            <input type="hidden" name="current_image" value="<?php echo $image; ?>"> <!-- Lưu hình ảnh hiện tại nếu không thay đổi -->

            <div>
                <label for="old_price">Giá cũ</label>
                <input type="text" name="old_price" value="<?php echo $oprice; ?>" required>
            </div>

            <div>
                <label for="new_price">Giá mới</label>
                <input type="text" name="new_price" value="<?php echo $nprice; ?>" required>
            </div>

            <div>
                <label for="discount">Phần trăm giảm giá</label>
                <input type="text" name="discount" value="<?php echo $discout; ?>" required>
            </div>

            <input type="submit" name="submit" value="Cập nhật">
            <a href="index.php"><input type="button" value="Hủy" class="cancel"></a>
        </form>
    </div>
</body>
</html>
